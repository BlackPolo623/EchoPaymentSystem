# Echo Payment System

現代科技感的線上金流開單系統

## 📁 檔案結構

```
payment-system/
├── css/
│   └── style.css          # 主題樣式 (淡藍色科技感)
├── js/
│   ├── script.js          # 主要邏輯
│   ├── background-resize.js # 背景調整
│   └── htmlcss.js         # 視覺效果
├── php/
│   ├── admin/
│   │   └── index.php      # 後台管理介面
│   ├── funpoint_payment_notify.php  # 信用卡回調
│   ├── atm_payment_notify.php       # ATM 付款回調
│   ├── atm_payment_info.php         # ATM 取號通知
│   ├── atm_redirect.php             # ATM 資訊顯示頁
│   ├── payment_result.php           # 付款結果頁
│   └── payment_return.php           # SmilePay 回調
├── data/                   # 交易資料目錄 (自動建立)
│   ├── transactions.json   # 完成交易記錄
│   └── pending_atm.json    # ATM 待處理訂單
├── image/                  # 圖片目錄 (可放 Logo)
├── index.html              # 主頁面 (付款表單)
└── simulate_funpoint_post.html  # 測試工具 (上線前刪除)
```

## ✨ 主要功能

### 1. 簡化開單流程
- ❌ 不需輸入帳號
- ✅ 只需輸入金額和選擇付款方式
- ✅ 快選按鈕 ($100 / $300 / $500 / $1000)

### 2. 訂單編號格式
- 前綴：`ECHO`
- 格式：`ECHO + 時間戳 + 亂數`
- 範例：`ECHO17356789012343456`

### 3. 支援的付款方式
- 💳 信用卡支付
- 🏧 ATM 虛擬帳號轉帳
- 🏪 7-11 ibon
- 🏪 全家 FamiPort

### 4. 檔案式交易記錄
- 所有交易記錄存儲在 `data/transactions.json`
- ATM 待處理訂單存儲在 `data/pending_atm.json`
- 不使用資料庫，方便部署

### 5. 後台管理
- 網址：`/php/admin/`
- 預設密碼：`echo2024admin`
- 功能：
  - 統計儀表板 (總交易數/金額、今日數據)
  - 待處理 ATM 訂單列表
  - 完整交易記錄 (分頁顯示)

## 🚀 部署步驟

### 1. 上傳檔案
將整個 `payment-system` 資料夾上傳到您的伺服器

### 2. 設定權限
```bash
chmod 755 data/
chmod 644 data/*.json
```

### 3. 修改設定
編輯 `js/script.js` 中的 CONFIG：

```javascript
const CONFIG = {
    funpoint: {
        ReturnURL: "https://您的網址/php/funpoint_payment_notify.php",
        ClientBackURL: "https://您的網址/index.html",
        OrderResultURL: "https://您的網址/php/payment_result.php",
        // ...
    }
};
```

### 4. 修改後台密碼
編輯 `php/admin/index.php`：

```php
$adminPassword = '您的新密碼';
```

### 5. 安全建議
- 上線前刪除 `simulate_funpoint_post.html`
- 為 `data/` 目錄添加 `.htaccess` 保護
- 為 `php/admin/` 添加額外的安全措施

## 🎨 主題特色

- **色調**：淡藍色 (#00d4ff) + 深色背景 (#0a0e17)
- **字體**：
  - 標題：Orbitron (科技感)
  - 內文：Rajdhani (現代)
  - 代碼：Space Mono (等寬)
- **效果**：
  - 動態網格背景
  - 自訂游標光暈
  - 浮動粒子效果
  - 漸變邊框動畫

## 📝 交易資料格式

```json
{
  "id": "NOTIFY_20250131123456_abc12345",
  "merchantTradeNo": "ECHO17356789012343456",
  "tradeNo": "金流平台編號",
  "amount": 500,
  "paymentType": "CREDIT",
  "paymentDate": "2025-01-31 12:34:56",
  "customField1": "ECHO17356789012343456",
  "status": "SUCCESS",
  "rtnCode": "1",
  "rtnMsg": "交易成功",
  "createdAt": "2025-01-31 12:34:56",
  "rawData": { ... }
}
```

## ⚠️ 注意事項

1. 本系統僅供開單使用，不會驗證使用者帳號
2. 所有交易記錄以 JSON 檔案方式儲存
3. 請定期備份 `data/` 目錄
4. 測試工具 (`simulate_funpoint_post.html`) 僅供開發測試使用

## 🔧 金流設定

### 歐買尬金流 (Funpoint)
- MerchantID: `1020977`
- 需要的回調 URL 設定請參考 `js/script.js`

### SmilePay
- dcvc: `16761`
- 適用於便利商店付款
